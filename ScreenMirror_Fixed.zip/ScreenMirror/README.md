# 📱 Screen Mirror — Live Android Screen to Browser

Stream your Android screen to any browser on your laptop over WiFi.
No USB, no ADB, no extra software needed on your laptop — just a browser.

---

## How It Works

```
Android Phone
  └── MediaProjection API captures frames
  └── JPEG-encodes each frame
  └── Built-in HTTP server streams MJPEG
         │
         │  WiFi (same network)
         │
Laptop Browser
  └── Opens http://PHONE_IP:8080
  └── Receives live MJPEG stream
  └── ~15–20 FPS live view
```

---

## Build & Install

### Requirements
- Android Studio Hedgehog or newer
- Android phone with Android 8.0+ (API 26+)
- USB cable for first install (or wireless ADB)

### Steps

1. **Open in Android Studio**
   ```
   File → Open → select the ScreenMirror folder
   ```

2. **Wait for Gradle sync** (first time downloads dependencies)

3. **Connect your phone via USB**, enable Developer Options + USB Debugging

4. **Run the app** — press the green ▶ button in Android Studio

5. **Or build APK manually:**
   ```
   Build → Build Bundle(s) / APK(s) → Build APK(s)
   ```
   APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

---

## Usage

### On Your Phone
1. Open **Screen Mirror** app
2. Make sure phone and laptop are on **the same WiFi network**
3. Note the IP address shown (e.g. `192.168.1.105`)
4. Tap **▶ Start Mirroring**
5. Grant the **screen capture permission** when prompted

### On Your Laptop Browser
1. Open Chrome, Firefox, Safari, or Edge
2. Go to: `http://PHONE_IP:8080`
   - Example: `http://192.168.1.105:8080`
3. The live stream starts automatically

---

## Browser Features

| Feature | How |
|---|---|
| Live stream (MJPEG) | Default mode, ~20 FPS |
| Auto-refresh mode | Click "🔄 Auto Refresh" |
| Fullscreen | Click "⛶ Fullscreen" |
| Screenshot | Click "📸 Screenshot" — saves JPEG |
| Direct snapshot URL | `http://PHONE_IP:8080/snapshot` |

---

## Endpoints

| URL | Description |
|---|---|
| `http://IP:8080/` | Browser viewer page |
| `http://IP:8080/stream` | Raw MJPEG stream |
| `http://IP:8080/snapshot` | Single JPEG snapshot |

---

## Troubleshooting

**"Not connected to WiFi" shown**
→ Connect phone to WiFi (not mobile data)

**Browser can't connect**
→ Check both devices are on the same WiFi network
→ Try disabling firewall temporarily on laptop
→ Make sure app is running and streaming is active

**Laggy stream**
→ Move closer to WiFi router
→ Use "Auto Refresh" mode with 250ms interval for lower CPU

**Black screen in browser**
→ The stream takes 1–2 seconds to start — wait a moment
→ Try refreshing the browser tab

**App crashes on start**
→ Make sure Android 8.0+ (API 26+)
→ Grant "Display over other apps" if prompted

---

## Architecture

```
com.screenmirror/
├── ui/
│   └── MainActivity.kt       ← UI, IP detection, permission request
├── encoder/
│   └── ScreenEncoder.kt      ← MediaProjection → JPEG frames
└── server/
    ├── MirrorService.kt      ← Foreground service (keeps app alive)
    └── HttpStreamServer.kt   ← HTTP server + MJPEG + HTML viewer
```

---

## Permissions Used

| Permission | Why |
|---|---|
| `INTERNET` | HTTP server on local network |
| `FOREGROUND_SERVICE` | Keep service alive while screen is off |
| `FOREGROUND_SERVICE_MEDIA_PROJECTION` | Required for Android 14+ screen capture |
| `WAKE_LOCK` | Prevent CPU sleep during streaming |

---

## Performance

| Setting | FPS | CPU Usage |
|---|---|---|
| 50ms interval | ~20 FPS | High |
| 100ms interval | ~10 FPS | Medium |
| 250ms interval | ~4 FPS | Low |

JPEG quality is set to 60% — good balance between quality and speed.
You can adjust `JPEG_QUALITY` in `ScreenEncoder.kt` (1–100).
