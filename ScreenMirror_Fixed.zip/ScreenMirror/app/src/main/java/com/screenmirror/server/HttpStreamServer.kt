package com.screenmirror.server

import android.util.Log
import com.screenmirror.encoder.ScreenEncoder
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class HttpStreamServer(
    private val port: Int,
    private val encoder: ScreenEncoder
) {
    companion object {
        private const val TAG = "HttpStreamServer"
        private const val BOUNDARY = "screenmirrorframe"
    }

    private var serverSocket: ServerSocket? = null
    private val isRunning = AtomicBoolean(false)
    private val threadPool = Executors.newCachedThreadPool()

    fun start() {
        if (isRunning.getAndSet(true)) return
        threadPool.execute { acceptConnections() }
        Log.d(TAG, "HTTP server started on port $port")
    }

    private fun acceptConnections() {
        try {
            serverSocket = ServerSocket(port)
            while (isRunning.get()) {
                val client = serverSocket?.accept() ?: break
                threadPool.execute { handleClient(client) }
            }
        } catch (e: Exception) {
            if (isRunning.get()) Log.e(TAG, "Server accept error: ${e.message}")
        }
    }

    private fun handleClient(socket: Socket) {
        try {
            socket.soTimeout = 30000
            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            val requestLine = reader.readLine() ?: return

            Log.d(TAG, "Request: $requestLine")

            // Read headers (consume them)
            var line = reader.readLine()
            while (!line.isNullOrBlank()) {
                line = reader.readLine()
            }

            when {
                requestLine.contains("/stream") -> handleMjpegStream(socket)
                requestLine.contains("/snapshot") -> handleSnapshot(socket)
                else -> handleHomePage(socket)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Client error: ${e.message}")
        } finally {
            try { socket.close() } catch (e: Exception) { }
        }
    }

    private fun handleHomePage(socket: Socket) {
        val html = buildHtmlPage()
        val out = socket.getOutputStream()
        val header = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: text/html; charset=UTF-8\r\n" +
                "Content-Length: ${html.toByteArray().size}\r\n" +
                "Connection: close\r\n\r\n"
        out.write(header.toByteArray())
        out.write(html.toByteArray())
        out.flush()
    }

    private fun handleMjpegStream(socket: Socket) {
        val out = socket.getOutputStream()
        val header = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: multipart/x-mixed-replace; boundary=$BOUNDARY\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: close\r\n\r\n"
        out.write(header.toByteArray())
        out.flush()

        var frameCount = 0
        while (isRunning.get() && !socket.isClosed) {
            try {
                val frame = encoder.getLatestFrame()
                if (frame != null) {
                    val partHeader = "--$BOUNDARY\r\n" +
                            "Content-Type: image/jpeg\r\n" +
                            "Content-Length: ${frame.size}\r\n\r\n"
                    out.write(partHeader.toByteArray())
                    out.write(frame)
                    out.write("\r\n".toByteArray())
                    out.flush()
                    frameCount++
                }
                Thread.sleep(50) // ~20 FPS
            } catch (e: Exception) {
                break
            }
        }
        Log.d(TAG, "MJPEG stream ended after $frameCount frames")
    }

    private fun handleSnapshot(socket: Socket) {
        val frame = encoder.getLatestFrame()
        if (frame == null) {
            val out = PrintWriter(socket.getOutputStream(), true)
            out.println("HTTP/1.1 503 Service Unavailable\r\n\r\nNo frame available yet")
            return
        }
        val out = socket.getOutputStream()
        val header = "HTTP/1.1 200 OK\r\n" +
                "Content-Type: image/jpeg\r\n" +
                "Content-Length: ${frame.size}\r\n" +
                "Cache-Control: no-cache\r\n" +
                "Connection: close\r\n\r\n"
        out.write(header.toByteArray())
        out.write(frame)
        out.flush()
    }

    private fun buildHtmlPage(): String {
        return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>📱 Screen Mirror</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    background: #0a0a0a;
    color: #e0e0e0;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  header {
    width: 100%;
    padding: 14px 24px;
    background: #111;
    border-bottom: 1px solid #222;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }
  header h1 { font-size: 18px; font-weight: 600; }
  .badge {
    background: #1a3a1a;
    color: #4caf50;
    border: 1px solid #2d6b2d;
    padding: 4px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    animation: pulse 2s infinite;
  }
  @keyframes pulse {
    0%,100% { opacity: 1; }
    50% { opacity: 0.6; }
  }
  .controls {
    display: flex;
    gap: 10px;
    padding: 14px 24px;
    background: #111;
    width: 100%;
    border-bottom: 1px solid #222;
    flex-wrap: wrap;
    align-items: center;
  }
  button {
    padding: 7px 16px;
    border-radius: 6px;
    border: 1px solid #333;
    background: #1e1e1e;
    color: #e0e0e0;
    cursor: pointer;
    font-size: 13px;
    transition: all 0.15s;
  }
  button:hover { background: #2a2a2a; border-color: #555; }
  button.active { background: #1a3a1a; border-color: #4caf50; color: #4caf50; }
  .fps-label { font-size: 12px; color: #888; margin-left: auto; }
  .screen-container {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
    width: 100%;
  }
  .phone-frame {
    position: relative;
    background: #1a1a1a;
    border-radius: 36px;
    border: 3px solid #333;
    padding: 12px;
    box-shadow: 0 0 0 1px #111, 0 20px 60px rgba(0,0,0,0.8);
    max-height: 85vh;
  }
  .phone-notch {
    width: 120px;
    height: 24px;
    background: #1a1a1a;
    border-radius: 0 0 14px 14px;
    margin: 0 auto 4px;
  }
  #screen {
    display: block;
    border-radius: 8px;
    max-height: calc(85vh - 80px);
    max-width: min(400px, 80vw);
    object-fit: contain;
    background: #000;
    min-width: 240px;
    min-height: 400px;
  }
  .info-bar {
    width: 100%;
    padding: 10px 24px;
    background: #111;
    border-top: 1px solid #222;
    display: flex;
    gap: 24px;
    font-size: 12px;
    color: #666;
  }
  .info-bar span { color: #aaa; }
  #loading {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;
    color: #555;
  }
  .spinner {
    width: 36px; height: 36px;
    border: 3px solid #222;
    border-top-color: #4caf50;
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
    margin: 0 auto 12px;
  }
  @keyframes spin { to { transform: rotate(360deg); } }
</style>
</head>
<body>

<header>
  <h1>📱 Screen Mirror</h1>
  <div class="badge" id="liveBadge">● LIVE</div>
</header>

<div class="controls">
  <button id="btnStream" class="active" onclick="setMode('stream')">📺 Live Stream</button>
  <button id="btnRefresh" onclick="setMode('refresh')">🔄 Auto Refresh</button>
  <button onclick="toggleFullscreen()">⛶ Fullscreen</button>
  <button onclick="takeScreenshot()">📸 Screenshot</button>
  <select id="qualitySelect" onchange="updateQuality()" style="padding:7px 12px;background:#1e1e1e;color:#e0e0e0;border:1px solid #333;border-radius:6px;font-size:13px;">
    <option value="50">Fast (50ms)</option>
    <option value="100" selected>Balanced (100ms)</option>
    <option value="250">Low CPU (250ms)</option>
  </select>
  <span class="fps-label" id="fpsLabel">FPS: --</span>
</div>

<div class="screen-container">
  <div class="phone-frame">
    <div class="phone-notch"></div>
    <div id="loading"><div class="spinner"></div><p>Waiting for stream…</p></div>
    <img id="screen" alt="Android Screen" style="display:none;" />
  </div>
</div>

<div class="info-bar">
  <div>Frames: <span id="frameCount">0</span></div>
  <div>Last update: <span id="lastUpdate">—</span></div>
  <div>Status: <span id="connStatus">Connecting…</span></div>
  <div>Mode: <span id="modeLabel">Stream</span></div>
</div>

<script>
  const screen = document.getElementById('screen');
  const loading = document.getElementById('loading');
  let frameCount = 0, lastFrameTime = Date.now();
  let fpsInterval, refreshInterval;
  let currentMode = 'stream';

  function updateFps() {
    const now = Date.now();
    const elapsed = (now - lastFrameTime) / 1000;
    const fps = (1 / elapsed).toFixed(1);
    document.getElementById('fpsLabel').textContent = 'FPS: ' + fps;
  }

  function showFrame() {
    loading.style.display = 'none';
    screen.style.display = 'block';
    frameCount++;
    lastFrameTime = Date.now();
    document.getElementById('frameCount').textContent = frameCount;
    document.getElementById('lastUpdate').textContent = new Date().toLocaleTimeString();
    document.getElementById('connStatus').textContent = 'Connected';
    updateFps();
  }

  function startStream() {
    document.getElementById('modeLabel').textContent = 'MJPEG Stream';
    screen.onload = showFrame;
    screen.onerror = () => {
      document.getElementById('connStatus').textContent = 'Stream error — retrying…';
      setTimeout(startStream, 2000);
    };
    screen.src = '/stream?' + Date.now();
  }

  function startRefreshMode() {
    document.getElementById('modeLabel').textContent = 'Auto Refresh';
    const delay = parseInt(document.getElementById('qualitySelect').value);
    clearInterval(refreshInterval);
    refreshInterval = setInterval(() => {
      const img = new Image();
      img.onload = () => { screen.src = img.src; showFrame(); };
      img.onerror = () => { document.getElementById('connStatus').textContent = 'Retrying…'; };
      img.src = '/snapshot?' + Date.now();
    }, delay);
  }

  function setMode(mode) {
    currentMode = mode;
    clearInterval(refreshInterval);
    screen.src = '';
    document.getElementById('btnStream').classList.toggle('active', mode === 'stream');
    document.getElementById('btnRefresh').classList.toggle('active', mode === 'refresh');
    if (mode === 'stream') startStream();
    else startRefreshMode();
  }

  function updateQuality() {
    if (currentMode === 'refresh') startRefreshMode();
  }

  function toggleFullscreen() {
    if (!document.fullscreenElement) document.documentElement.requestFullscreen();
    else document.exitFullscreen();
  }

  function takeScreenshot() {
    const link = document.createElement('a');
    link.href = '/snapshot?' + Date.now();
    link.download = 'screenshot_' + Date.now() + '.jpg';
    link.click();
  }

  // Start
  startStream();
</script>
</body>
</html>"""
    }

    fun stop() {
        isRunning.set(false)
        try { serverSocket?.close() } catch (e: Exception) { }
        threadPool.shutdownNow()
        Log.d(TAG, "HTTP server stopped")
    }
}
