package com.screenmirror.ui

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.screenmirror.databinding.ActivityMainBinding
import com.screenmirror.server.MirrorService
import java.net.NetworkInterface

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var mediaProjectionManager: MediaProjectionManager
    private var isStreaming = false

    companion object {
        const val PORT = 8080
    }

    private val projectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            startMirrorService(result.resultCode, result.data!!)
        } else {
            Toast.makeText(this, "Screen capture permission denied", Toast.LENGTH_SHORT).show()
            updateUI(false)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        mediaProjectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE)
                as MediaProjectionManager

        setupUI()
        displayConnectionInfo()
    }

    private fun setupUI() {
        binding.btnStartStop.setOnClickListener {
            if (!isStreaming) {
                requestScreenCapture()
            } else {
                stopMirroring()
            }
        }

        binding.btnRefreshIp.setOnClickListener {
            displayConnectionInfo()
        }
    }

    private fun requestScreenCapture() {
        updateUI(true)
        val captureIntent = mediaProjectionManager.createScreenCaptureIntent()
        projectionLauncher.launch(captureIntent)
    }

    private fun startMirrorService(resultCode: Int, data: Intent) {
        val serviceIntent = Intent(this, MirrorService::class.java).apply {
            putExtra(MirrorService.EXTRA_RESULT_CODE, resultCode)
            putExtra(MirrorService.EXTRA_DATA, data)
        }
        startForegroundService(serviceIntent)
        isStreaming = true
        updateUI(true)
        Toast.makeText(this, "Mirroring started! Open browser on your laptop.", Toast.LENGTH_LONG).show()
    }

    private fun stopMirroring() {
        val serviceIntent = Intent(this, MirrorService::class.java)
        stopService(serviceIntent)
        isStreaming = false
        updateUI(false)
        Toast.makeText(this, "Mirroring stopped.", Toast.LENGTH_SHORT).show()
    }

    private fun updateUI(streaming: Boolean) {
        isStreaming = streaming
        if (streaming) {
            binding.btnStartStop.text = "⏹ Stop Mirroring"
            binding.btnStartStop.setBackgroundColor(getColor(android.R.color.holo_red_dark))
            binding.tvStatus.text = "🟢 LIVE — Streaming to browser"
            binding.tvStatus.setTextColor(getColor(android.R.color.holo_green_dark))
            binding.cardBrowserUrl.alpha = 1f
        } else {
            binding.btnStartStop.text = "▶ Start Mirroring"
            binding.btnStartStop.setBackgroundColor(getColor(android.R.color.holo_green_dark))
            binding.tvStatus.text = "⚫ Not streaming"
            binding.tvStatus.setTextColor(getColor(android.R.color.darker_gray))
            binding.cardBrowserUrl.alpha = 0.5f
        }
    }

    private fun displayConnectionInfo() {
        val ip = getWifiIpAddress()
        if (ip != null) {
            val url = "http://$ip:$PORT"
            binding.tvIpAddress.text = ip
            binding.tvBrowserUrl.text = url
            binding.tvPort.text = PORT.toString()
        } else {
            binding.tvIpAddress.text = "Not connected to WiFi"
            binding.tvBrowserUrl.text = "Connect to WiFi first"
            binding.tvPort.text = "-"
        }
    }

    private fun getWifiIpAddress(): String? {
        try {
            // Try NetworkInterface for more reliable results
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                if (iface.name.startsWith("wlan") || iface.name.startsWith("eth")) {
                    val addresses = iface.inetAddresses
                    while (addresses.hasMoreElements()) {
                        val addr = addresses.nextElement()
                        if (!addr.isLoopbackAddress && addr.hostAddress?.contains('.') == true) {
                            return addr.hostAddress
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // Fallback to WifiManager
        }

        // Fallback: WifiManager
        try {
            val wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            val ipInt = wifiManager.connectionInfo.ipAddress
            if (ipInt != 0) {
                return String.format(
                    "%d.%d.%d.%d",
                    ipInt and 0xff,
                    (ipInt shr 8) and 0xff,
                    (ipInt shr 16) and 0xff,
                    (ipInt shr 24) and 0xff
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isStreaming) stopMirroring()
    }
}
