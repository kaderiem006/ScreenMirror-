package com.screenmirror.encoder

import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.util.Log
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

class ScreenEncoder(
    private val mediaProjection: MediaProjection,
    private val width: Int,
    private val height: Int,
    private val dpi: Int
) {
    companion object {
        private const val TAG = "ScreenEncoder"
        private const val VIRTUAL_DISPLAY_NAME = "ScreenMirrorDisplay"
        private const val JPEG_QUALITY = 60  // Balance between quality and speed
    }

    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private val isRunning = AtomicBoolean(false)
    private val latestFrame = AtomicReference<ByteArray>(null)

    fun start() {
        if (isRunning.getAndSet(true)) return

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            try {
                val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                val planes = image.planes
                val buffer = planes[0].buffer
                val pixelStride = planes[0].pixelStride
                val rowStride = planes[0].rowStride
                val rowPadding = rowStride - pixelStride * width

                val bitmap = Bitmap.createBitmap(
                    width + rowPadding / pixelStride,
                    height,
                    Bitmap.Config.ARGB_8888
                )
                bitmap.copyPixelsFromBuffer(buffer)

                // Crop to exact dimensions if there's row padding
                val cropped = if (rowPadding > 0) {
                    Bitmap.createBitmap(bitmap, 0, 0, width, height)
                } else bitmap

                val out = ByteArrayOutputStream()
                cropped.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
                latestFrame.set(out.toByteArray())

                if (cropped !== bitmap) cropped.recycle()
                bitmap.recycle()
                image.close()
            } catch (e: Exception) {
                Log.e(TAG, "Frame capture error: ${e.message}")
            }
        }, null)

        virtualDisplay = mediaProjection.createVirtualDisplay(
            VIRTUAL_DISPLAY_NAME,
            width, height, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface,
            null, null
        )

        Log.d(TAG, "ScreenEncoder started: ${width}x${height} @ ${dpi}dpi")
    }

    fun getLatestFrame(): ByteArray? = latestFrame.get()

    fun stop() {
        isRunning.set(false)
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        latestFrame.set(null)
        Log.d(TAG, "ScreenEncoder stopped")
    }
}
